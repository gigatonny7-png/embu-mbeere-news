# EMBU & MBEERE NEWS

A Next.js + TypeScript + Tailwind + Supabase foundation for an independent Embu County digital news and civic-information platform.

## What's included
- Responsive editorial homepage and branded navigation.
- News feed that reads published articles from Supabase.
- Sections for Embu, Mbeere, politics, 2027 tracker, polls, community, about, contact and policies.
- Admin landing page and secure-role setup instructions.
- PostgreSQL schema for profiles, roles, news, comments, candidates, parties, constituencies, wards, polls, poll options, votes, tips, discussions, notifications, ads and audit logs.
- Database uniqueness constraint for one vote per account per poll and a server-side database function that requires an authenticated account with a phone-verification timestamp.
- Row Level Security policies and a manual Super Admin bootstrap step.

## Requirements
- Node.js 20.9 or newer
- A Supabase project

## Run locally
1. Copy `.env.example` to `.env.local`.
2. Add your Supabase project URL and anon key.
3. In Supabase SQL Editor, run `supabase/migrations/001_initial_schema.sql`.
4. Install dependencies: `npm install`.
5. Start: `npm run dev` and open http://localhost:3000.

## Super Admin bootstrap
1. Register your own account using Supabase Auth and complete email verification.
2. Add phone verification through a configured SMS provider before enabling voting. Do not mark phone numbers verified just because a user typed one.
3. In Supabase SQL Editor, run the following after replacing the email with your verified account email:

```sql
update public.profiles
set role = 'super_admin'
where id = (select id from auth.users where email = 'YOUR_VERIFIED_EMAIL');
```

4. Confirm exactly one profile was updated. Keep the service-role key server-side only. Do not expose it as a `NEXT_PUBLIC_` variable.

## Important production work still required
This is a working project foundation, not a deployed/production-certified news platform. Before launch, implement and test the remaining authenticated UI and server actions for sign-up/login, SMS OTP provider integration, article authoring, moderation, poll creation and voting screens, results visibility rules, CSV export, image/video upload buckets, audit-log append-only enforcement, rate limiting/CAPTCHA, email notifications, account suspension, full role-management workflows, privacy consent/retention and backups. The SQL vote function is the only intended vote-writing path; never permit direct client inserts into `votes`. Add a restrictive `votes` insert policy only if the architecture is deliberately changed and reviewed.

For production, add server-side authorization checks to every mutation, verify webhook signatures, configure Supabase Storage policies, use a trusted SMS OTP provider, and have the privacy notice and data-retention plan reviewed for compliance with Kenya's Data Protection Act, 2019. Online polls are not official IEBC polls and phone OTP alone does not prove one human identity.

## Deploy
1. Push the project to a private GitHub repository.
2. Import it into Vercel.
3. Set `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `NEXT_PUBLIC_SITE_URL` in Vercel environment settings.
4. Keep `SUPABASE_SERVICE_ROLE_KEY` only in server runtime secrets if a future server-only workflow needs it.
5. Deploy and test on Android and desktop, including access-control tests with separate member/editor/admin accounts.

## Seed categories
Run this optional SQL in Supabase after the migration:

```sql
insert into public.categories(name,slug) values
('Breaking News','breaking-news'),('Embu County News','embu-county-news'),
('Mbeere North News','mbeere-north-news'),('Mbeere South News','mbeere-south-news'),
('Manyatta News','manyatta-news'),('Runyenjes News','runyenjes-news'),
('Embu Politics','embu-politics'),('Mbeere Politics','mbeere-politics'),
('2027 Elections','2027-elections'),('County Government','county-government'),
('Development Projects','development-projects'),('Education','education'),
('Agriculture','agriculture'),('Business','business'),('Youth Affairs','youth-affairs'),
('Sports','sports'),('Entertainment','entertainment'),('National News','national-news')
on conflict(slug) do nothing;
```
