import type { Config } from 'tailwindcss';
export default { content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'], theme: { extend: { colors: { forest: '#123d2b', leaf: '#1f704b', ink: '#17211b' } } }, plugins: [] } satisfies Config;
